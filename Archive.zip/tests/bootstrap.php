<?php

$loader = require __DIR__.'/../vendor/autoload.php';
$loader->add('SwfTools\Tests', __DIR__);
